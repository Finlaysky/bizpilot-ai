# BizPilot AI
**Your business. Intelligently run.**

Mobile-first AI business assistant for small businesses worldwide.

## Current MVP
- Responsive dashboard and navigation
- Six AI business-writing workflows
- Local template preview mode (not a live AI connection)
- Proposed subscription plan display (payments not connected)
- Workspace settings UI (not cloud-persisted)
- Insights placeholder (no fabricated business metrics)

## Run locally
Requires Node.js 20+.

```bash
npm install
npm run dev
```

Build with `npm run build`.

## Next milestones
1. Configure Supabase authentication, database and row-level security.
2. Add a server-side AI endpoint; never expose provider keys in browser code.
3. Persist workspaces, generated content and usage records.
4. Add checkout, verified payment webhooks and server-enforced plan limits.
5. Add owner-only administration with server-side role checks and audit logs.
6. Package for iOS and Android with Expo after validating the web MVP.

## Security
Never commit service-role keys, AI provider keys, payment secrets or privileged credentials. Configure secrets in the hosting provider. Enable row-level security before storing customer data.

## Product note
Plan prices are proposed USD pricing for testing, not active offers. Live AI, authentication, payments, cloud persistence and owner administration are not active yet.
