import { useState } from "react";
import { Activity, ArrowRight, BarChart3, Bot, Check, ChevronDown, CircleHelp, CreditCard, FileText, LayoutDashboard, Lightbulb, Menu, MessageCircle, Plus, Send, Settings, ShieldCheck, Sparkles, Target, TrendingUp, WandSparkles, X, Zap } from "lucide-react";

const tools = [
  ["reply", MessageCircle, "Customer reply", "Write helpful, human customer responses.", "Support"],
  ["social", Sparkles, "Social media post", "Create engaging posts for your next campaign.", "Marketing"],
  ["ad", Target, "Ad campaign", "Turn an offer into persuasive ad copy.", "Marketing"],
  ["product", FileText, "Product description", "Make product benefits clear and compelling.", "Sales"],
  ["followup", Send, "Lead follow-up", "Reconnect with a potential customer.", "Sales"],
  ["ideas", Lightbulb, "Business ideas", "Find practical ways to improve your business.", "Growth"]
];
const prompts = {
 reply:"A customer says their order is late and they are frustrated. Write a warm, professional reply that apologizes, reassures them and asks for their order number.",
 social:"Write an engaging social media post introducing my business and inviting people to explore its products. Keep it friendly and include a call to action.",
 ad:"Create a short ad campaign for my promotion. Include a headline, main copy and call to action.",
 product:"Write a clear, benefit-focused product description. Include key benefits and a short call to action.",
 followup:"Write a polite follow-up message to a potential customer who asked about a product but has not replied.",
 ideas:"Suggest five practical, low-cost ways a small business can attract new customers and improve repeat sales."
};
function preview(kind, name, context) {
 const brand=name.trim() || "your business";
 const intro={
 reply:"Hi there, thank you for letting us know. We’re sorry for the delay and understand how frustrating this must be.",
 social:`A little introduction from ${brand} 👋`,
 ad:`A great offer from ${brand} starts here.`,
 product:"Meet a product designed to make your day a little easier.",
 followup:"Hi! Just checking in on your recent enquiry.",
 ideas:`Here are five practical growth moves for ${brand}:`
 }[kind];
 const body={
 reply:"We’re checking this for you and will do our best to get it resolved quickly. Please send us your order number so we can look into it right away. Thank you for your patience.",
 social:"We’re here to make things simpler, better and more enjoyable. Take a look at what we offer and let us know how we can help. Send us a message today!",
 ad:"Discover what makes us different, enjoy friendly service and find the right option for you. Get in touch today to learn more.",
 product:"Designed with your needs in mind, it offers a simple and dependable way to get the job done. Explore the details and contact us with any questions.",
 followup:"I’d be happy to answer any questions or help you choose the option that works best. No pressure at all — just reply whenever it’s convenient.",
 ideas:"1. Share useful customer tips consistently.\\n2. Ask happy customers for reviews.\\n3. Create a simple referral offer.\\n4. Follow up with past enquiries.\\n5. Highlight one customer success story each week."
 }[kind];
 return intro+(context.trim()?"\\n\\nContext: "+context.trim():"")+"\\n\\n"+body;
}
export default function App(){
 const [page,setPage]=useState("Overview"),[mobile,setMobile]=useState(false),[kind,setKind]=useState("social"),[business,setBusiness]=useState(""),[context,setContext]=useState(""),[result,setResult]=useState(""),[notice,setNotice]=useState("");
 const [copied,setCopied]=useState(false);
 const nav=[["Overview",LayoutDashboard],["AI assistant",Bot],["AI tools",WandSparkles],["Insights",BarChart3],["Plans & billing",CreditCard],["Settings",Settings]];
 const run=()=>{setResult(preview(kind,business,context));setNotice("Preview generated locally. Connect an AI provider to enable live AI responses.");};
 const copy=async()=>{try{await navigator.clipboard.writeText(result);setCopied(true);setTimeout(()=>setCopied(false),1500)}catch{setNotice("Please select and copy the text manually.")}};
 return <div className="shell">
 <aside className={mobile?"sidebar open":"sidebar"}>
  <div className="brand"><div className="mark"><Zap size={21}/></div><div><b>BizPilot <i>AI</i></b><small>BUSINESS, IN GOOD HANDS</small></div><button className="close mobile-only" onClick={()=>setMobile(false)}><X/></button></div>
  <div className="workspace"><div className="workspace-mark">B</div><div><b>My workspace</b><small>Starter workspace</small></div><ChevronDown size={15}/></div>
  <p className="nav-label">WORKSPACE</p>{nav.slice(0,4).map(([n,I])=><button className={page===n?"nav active":"nav"} key={n} onClick={()=>{setPage(n);setMobile(false)}}><I size={18}/>{n}</button>)}
  <p className="nav-label">MANAGE</p>{nav.slice(4).map(([n,I])=><button className={page===n?"nav active":"nav"} key={n} onClick={()=>{setPage(n);setMobile(false)}}><I size={18}/>{n}</button>)}
  <div className="side-bottom"><div className="help"><CircleHelp size={19}/><b>Need a hand?</b><p>Explore the workspace and see what BizPilot can do.</p><span>Help centre <ArrowRight size={13}/></span></div><div className="account"><div className="user">U</div><div><b>Your account</b><small>Workspace owner</small></div></div></div>
 </aside>{mobile&&<button className="scrim" onClick={()=>setMobile(false)} aria-label="Close menu"/>}
 <main className="main"><header className="top"><button className="menu mobile-only" onClick={()=>setMobile(true)}><Menu/></button><div className="crumb">Workspace <span>/</span> <b>{page}</b></div><div className="top-right"><span className="preview-pill">● Preview mode</span><CircleHelp size={18}/><div className="user tiny">U</div></div></header>
 <div className="content">
 {page==="Overview"&&<>
 <div className="welcome"><div><div className="eyebrow"><Sparkles size={14}/> YOUR BUSINESS, IN GOOD HANDS</div><h1>Good to see you<span>.</span></h1><p>Make today a little more productive. What would you like to work on?</p></div><span className="global">◎ Built for business everywhere</span></div>
 <section className="hero"><div className="hero-copy"><div className="hero-kicker"><Zap size={14}/> YOUR AI WORKSPACE</div><h2>Less busywork.<br/><em>More business.</em></h2><p>Get a head start on customer replies, marketing and sales with practical AI tools built for small businesses.</p><button className="primary" onClick={()=>setPage("AI assistant")}>Meet your AI assistant <ArrowRight size={16}/></button></div><div className="hero-visual"><div className="glow"/><div className="mock-chat"><div className="mock-head"><Sparkles size={14}/> BizPilot assistant <i/></div><div className="bubble">Help me write a launch post</div><div className="answer"><b>Absolutely. Let’s make it stand out.</b><hr/><hr/><hr/></div><div className="mock-foot">✨ Ready when you are</div></div><span className="float one"><TrendingUp size={15}/> Grow with clarity</span><span className="float two"><ShieldCheck size={15}/> Your workspace</span></div></section>
 <div className="section-head"><div><h3>Start with a little help</h3><p>Choose a task and let’s get moving.</p></div><button className="link" onClick={()=>setPage("AI tools")}>Explore all tools ↗</button></div>
 <div className="tools four">{tools.slice(0,4).map(([id,I,title,desc,tag])=><button className="tool" key={id} onClick={()=>{setKind(id);setPage("AI assistant")}}><div className="tool-icon"><I size={19}/></div><small>{tag}</small><b>{title}</b><p>{desc}</p><span className="arrow">↗</span></button>)}</div>
 <div className="lower"><div className="panel"><div className="section-head"><div><h3>Your workspace</h3><p>A simple place to get started.</p></div><span className="tag">Getting started</span></div><div className="todo"><span className="done"><Check size={14}/></span><div><b>Explore your AI tools</b><small>See what you can create for your business.</small></div><button onClick={()=>setPage("AI tools")}>Explore</button></div><div className="todo"><span className="add"><Plus size={14}/></span><div><b>Add your business details</b><small>Give your workspace a little context.</small></div><button onClick={()=>setPage("Settings")}>Set up</button></div></div><div className="tip"><Lightbulb size={21}/><small>A SMALL TIP</small><h3>Start with one thing.</h3><p>Try creating a customer reply or social post. Small improvements add up.</p><button onClick={()=>setPage("AI assistant")}>Try the assistant ↗</button></div></div>
 </>}
 {page==="AI assistant"&&<><div className="page-title"><div className="eyebrow"><Bot size={14}/> YOUR AI ASSISTANT</div><h1>How can I help?</h1><p>Tell BizPilot what you’re working on and get a useful starting point.</p></div><div className="assistant"><div className="panel form"><label>Business name <small>Optional</small></label><input value={business} onChange={e=>setBusiness(e.target.value)} placeholder="e.g. Bloom & Co."/><label>What do you need help with?</label><div className="choices">{tools.map(([id,I,title])=><button className={kind===id?"choice selected":"choice"} key={id} onClick={()=>setKind(id)}><I size={16}/>{title}</button>)}</div><label>Give a little context <small>More detail = a better result</small></label><textarea rows="5" value={context} onChange={e=>setContext(e.target.value)} placeholder={prompts[kind]}/><button className="primary wide" onClick={run}><Sparkles size={16}/> Generate a preview</button><p className="fine">Preview mode uses sample templates in this browser. Live AI requires a securely configured API connection.</p></div><div className="panel output"><div className="section-head"><div><h3>Your result</h3><p>A starting point you can make your own.</p></div><span className="tag">Draft</span></div>{result?<><pre>{result}</pre><button className="secondary" onClick={copy}>{copied?<Check size={15}/>:<FileText size={15}/>} {copied?"Copied":"Copy text"}</button></>:<div className="empty"><div><WandSparkles size={24}/></div><b>Your next good idea starts here.</b><p>Choose a task, add a little context and generate your first draft.</p></div>}</div></div></>}
 {page==="AI tools"&&<><div className="page-title"><div className="eyebrow"><WandSparkles size={14}/> THE TOOLKIT</div><h1>Tools for the work that matters.</h1><p>Practical starting points for your everyday business tasks.</p></div><div className="tools three">{tools.map(([id,I,title,desc,tag])=><button className="tool" key={id} onClick={()=>{setKind(id);setPage("AI assistant")}}><div className="tool-icon"><I size={19}/></div><small>{tag}</small><b>{title}</b><p>{desc}</p><span className="arrow">↗</span></button>)}</div></>}
 {page==="Insights"&&<><div className="page-title"><div className="eyebrow"><Activity size={14}/> BUSINESS INSIGHTS</div><h1>See the bigger picture.</h1><p>Your business insights will live here as you connect your tools and data.</p></div><div className="panel empty"><div><BarChart3 size={24}/></div><h3>Your insights are getting ready.</h3><p>Connect real business data in a later setup step to see useful trends and reports. We don't invent sales figures.</p></div></>}
 {page==="Plans & billing"&&<><div className="page-title"><div className="eyebrow"><CreditCard size={14}/> PLANS & BILLING</div><h1>A plan that grows with you.</h1><p>Explore proposed plans. Payments are not enabled in this preview.</p></div><div className="plans">{[["Starter","$9","For trying the essentials",["AI writing tools","Basic workspace","Limited monthly usage"]],["Professional","$29","For growing businesses",["More AI usage","All writing tools","Saved work"]],["Business","$79","For teams doing more",["Higher usage limits","Team workspace","Priority support"]]].map(([n,p,d,items])=><div className="panel plan" key={n}><span className="tag">{n}</span><h2>{p}<small>/ month</small></h2><p>{d}</p>{items.map(x=><div className="feature" key={x}><Check size={14}/>{x}</div>)}<button className="secondary" onClick={()=>setNotice("Subscriptions are not connected yet. Payment setup comes after backend configuration.")}>Coming soon</button></div>)}</div><p className="fine center">Illustrative USD pricing. Final prices, taxes, usage limits and payment availability will be confirmed before launch.</p></>}
 {page==="Settings"&&<><div className="page-title"><div className="eyebrow"><Settings size={14}/> WORKSPACE SETTINGS</div><h1>Make it yours.</h1><p>Set up the details that help BizPilot understand your business.</p></div><div className="panel settings"><label>Business name</label><input value={business} onChange={e=>setBusiness(e.target.value)} placeholder="Your business name"/><label>What does your business do?</label><textarea rows="4" value={context} onChange={e=>setContext(e.target.value)} placeholder="Describe your products, services and customers..."/><button className="primary" onClick={()=>setNotice("These details are currently held only in this page session. Cloud account storage will be added with Supabase.")}>Save workspace details</button><p className="fine">This preview does not yet save details to a cloud account.</p></div><div className="panel security"><ShieldCheck/><div><b>Security comes first</b><p>Authentication, account storage and owner-only administration will be connected before public launch.</p></div></div></>}
 <footer>© 2026 BizPilot AI <span>Built to help good businesses grow.</span></footer>
 </div></main>
 {notice&&<div className="notice" role="status">{notice}<button onClick={()=>setNotice("")}><X size={15}/></button></div>}
 </div>;
}